﻿function prwto_mhnyma()
{
	if(document.getElementById("pedio_eisagwghs").value == "enter amount") {
		document.getElementById("pedio_eisagwghs").value = "";
	}
}
